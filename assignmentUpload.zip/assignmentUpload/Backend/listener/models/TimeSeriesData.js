const mongoose = require('mongoose');

const timeSeriesDataSchema = new mongoose.Schema({
  minute: {
    type: Date,
    required: true,
    index: true
  },
  records: [{
    name: String,
    origin: String,
    destination: String,
    secret_key: String,
    timestamp: {
      type: Date,
      required: true
    }
  }],
  recordCount: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Compound index for efficient time-series queries
timeSeriesDataSchema.index({ minute: -1, 'records.timestamp': 1 });

// Static method to find or create a minute document
timeSeriesDataSchema.statics.findOrCreateForMinute = async function(timestamp) {
  const minute = new Date(timestamp);
  minute.setSeconds(0, 0); // Round to the nearest minute

  let doc = await this.findOne({ minute });
  
  if (!doc) {
    doc = new this({
      minute,
      records: []
    });
  }

  return doc;
};

module.exports = mongoose.model('TimeSeriesData', timeSeriesDataSchema);