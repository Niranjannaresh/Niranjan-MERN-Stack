// const { Server } = require('socket.io');
// const http = require('http');
// const crypto = require('crypto');
// const connectDB = require('./db');
// const TimeSeriesData = require('./models/TimeSeriesData');
// require('dotenv').config();

// const ENCRYPTION_KEY = 'mysecretkey123456789012345678901234'; // 32 bytes for aes-256
// const ALGORITHM = 'aes-256-ctr';
// const PORT = process.env.LISTENER_PORT || 3001;

// class ListenerService {
//   constructor() {
//     this.server = http.createServer();
//     this.io = new Server(this.server, {
//       cors: {
//         origin: '*',
//         methods: ['GET', 'POST']
//       }
//     });

//     this.setupSocketHandlers();
//     this.connectToDatabase();
//   }

//   async connectToDatabase() {
//     await connectDB();
//   }

//   setupSocketHandlers() {
//     this.io.on('connection', (socket) => {
//       console.log('Emitter connected:', socket.id);

//       socket.on('data-stream', async (encryptedStream) => {
//         try {
//           await this.processStream(encryptedStream);
//         } catch (error) {
//           console.error('Error processing stream:', error.message);
//         }
//       });

//       socket.on('disconnect', () => {
//         console.log('Emitter disconnected:', socket.id);
//       });
//     });
//   }

//   decryptMessage(encryptedData) {
//     try {
//       // Split IV and encrypted data
//       const [ivHex, encryptedHex] = encryptedData.split(':');
      
//       if (!ivHex || !encryptedHex) {
//         throw new Error('Invalid encrypted data format');
//       }

//       const iv = Buffer.from(ivHex, 'hex');
//       const encrypted = Buffer.from(encryptedHex, 'hex');

//       const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(ENCRYPTION_KEY), iv);
      
//       const decrypted = Buffer.concat([
//         decipher.update(encrypted),
//         decipher.final()
//       ]);

//       return JSON.parse(decrypted.toString('utf8'));
//     } catch (error) {
//       throw new Error(`Decryption failed: ${error.message}`);
//     }
//   }

//   validateMessage(message) {
//     try {
//       const { name, origin, destination, secret_key } = message;

//       if (!name || !origin || !destination || !secret_key) {
//         return false;
//       }

//       const originalMessage = { name, origin, destination };
//       const calculatedHash = crypto.createHash('sha256')
//         .update(JSON.stringify(originalMessage))
//         .digest('hex');

//       return calculatedHash === secret_key;
//     } catch (error) {
//       return false;
//     }
//   }

//   async processStream(encryptedStream) {
//     const encryptedMessages = encryptedStream.split('|');
//     console.log(`Processing stream with ${encryptedMessages.length} messages`);

//     const validMessages = [];

//     for (const encryptedMsg of encryptedMessages) {
//       try {
//         // Decrypt the message
//         const decryptedMessage = this.decryptMessage(encryptedMsg);
        
//         // Validate the message
//         if (this.validateMessage(decryptedMessage)) {
//           // Add timestamp
//           const messageWithTimestamp = {
//             ...decryptedMessage,
//             timestamp: new Date()
//           };
//           validMessages.push(messageWithTimestamp);
//         } else {
//           console.log('Message validation failed, skipping');
//         }
//       } catch (error) {
//         console.log('Failed to process message:', error.message);
//         // Continue to next message
//       }
//     }

//     if (validMessages.length > 0) {
//       await this.saveToTimeSeriesDB(validMessages);
//       console.log(`Saved ${validMessages.length} valid messages to database`);
//     }
//   }

//   async saveToTimeSeriesDB(messages) {
//     // Group messages by minute
//     const messagesByMinute = {};

//     for (const message of messages) {
//       const minute = new Date(message.timestamp);
//       minute.setSeconds(0, 0);
//       const minuteKey = minute.toISOString();

//       if (!messagesByMinute[minuteKey]) {
//         messagesByMinute[minuteKey] = [];
//       }

//       messagesByMinute[minuteKey].push(message);
//     }

//     // Save each minute group
//     for (const [minuteKey, minuteMessages] of Object.entries(messagesByMinute)) {
//       const minute = new Date(minuteKey);
      
//       // Find or create the minute document
//       let minuteDoc = await TimeSeriesData.findOne({ minute });

//       if (!minuteDoc) {
//         minuteDoc = new TimeSeriesData({
//           minute,
//           records: []
//         });
//       }

//       // Add new records
//       minuteDoc.records.push(...minuteMessages);
//       minuteDoc.recordCount = minuteDoc.records.length;
      
//       await minuteDoc.save();
//     }
//   }

//   start() {
//     this.server.listen(PORT, () => {
//       console.log(`Listener service running on port ${PORT}`);
//     });
//   }
// }

// // Start the listener service
// const listener = new ListenerService();
// listener.start();

// // Handle graceful shutdown
// process.on('SIGINT', async () => {
//   console.log('Shutting down listener service...');
//   await mongoose.connection.close();
//   process.exit(0);
// });














const { Server } = require('socket.io');
const http = require('http');
const crypto = require('crypto');
const connectDB = require('./db');
const TimeSeriesData = require('./models/TimeSeriesData');
require('dotenv').config();

// Fix: Same key generation as emitter
const ENCRYPTION_KEY = crypto.createHash('sha256')
  .update('mysecretkey')
  .digest('hex')
  .substring(0, 32); // 32 bytes for aes-256

const ALGORITHM = 'aes-256-ctr';
const PORT = process.env.LISTENER_PORT || 3001;

class ListenerService {
  constructor() {
    this.server = http.createServer();
    this.io = new Server(this.server, {
      cors: {
        origin: '*',
        methods: ['GET', 'POST']
      }
    });

    this.setupSocketHandlers();
    this.connectToDatabase();
  }

  async connectToDatabase() {
    try {
      await connectDB();
    } catch (error) {
      console.error('Database connection error:', error);
    }
  }

  setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log('Emitter connected:', socket.id);

      socket.on('data-stream', async (encryptedStream) => {
        try {
          await this.processStream(encryptedStream);
        } catch (error) {
          console.error('Error processing stream:', error.message);
        }
      });

      socket.on('disconnect', () => {
        console.log('Emitter disconnected:', socket.id);
      });
    });
  }

  decryptMessage(encryptedData) {
    try {
      // Split IV and encrypted data
      const [ivHex, encryptedHex] = encryptedData.split(':');
      
      if (!ivHex || !encryptedHex) {
        throw new Error('Invalid encrypted data format');
      }

      const iv = Buffer.from(ivHex, 'hex');
      const encrypted = Buffer.from(encryptedHex, 'hex');
      
      // Fix: Use same key buffer creation method
      const key = Buffer.from(ENCRYPTION_KEY, 'utf8');

      const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
      
      const decrypted = Buffer.concat([
        decipher.update(encrypted),
        decipher.final()
      ]);

      return JSON.parse(decrypted.toString('utf8'));
    } catch (error) {
      throw new Error(`Decryption failed: ${error.message}`);
    }
  }

  validateMessage(message) {
    try {
      const { name, origin, destination, secret_key } = message;

      if (!name || !origin || !destination || !secret_key) {
        return false;
      }

      const originalMessage = { name, origin, destination };
      const calculatedHash = crypto.createHash('sha256')
        .update(JSON.stringify(originalMessage))
        .digest('hex');

      return calculatedHash === secret_key;
    } catch (error) {
      return false;
    }
  }

  async processStream(encryptedStream) {
    const encryptedMessages = encryptedStream.split('|');
    console.log(`Processing stream with ${encryptedMessages.length} messages`);

    const validMessages = [];

    for (const encryptedMsg of encryptedMessages) {
      try {
        // Decrypt the message
        const decryptedMessage = this.decryptMessage(encryptedMsg);
        
        // Validate the message
        if (this.validateMessage(decryptedMessage)) {
          // Add timestamp
          const messageWithTimestamp = {
            ...decryptedMessage,
            timestamp: new Date()
          };
          validMessages.push(messageWithTimestamp);
        } else {
          console.log('Message validation failed, skipping');
        }
      } catch (error) {
        console.log('Failed to process message:', error.message);
        // Continue to next message
      }
    }

    if (validMessages.length > 0) {
      await this.saveToTimeSeriesDB(validMessages);
      console.log(`Saved ${validMessages.length} valid messages to database`);
    }
  }

  async saveToTimeSeriesDB(messages) {
    try {
      // Group messages by minute
      const messagesByMinute = {};

      for (const message of messages) {
        const minute = new Date(message.timestamp);
        minute.setSeconds(0, 0);
        const minuteKey = minute.toISOString();

        if (!messagesByMinute[minuteKey]) {
          messagesByMinute[minuteKey] = [];
        }

        messagesByMinute[minuteKey].push(message);
      }

      // Save each minute group
      for (const [minuteKey, minuteMessages] of Object.entries(messagesByMinute)) {
        const minute = new Date(minuteKey);
        
        // Find or create the minute document
        let minuteDoc = await TimeSeriesData.findOne({ minute });

        if (!minuteDoc) {
          minuteDoc = new TimeSeriesData({
            minute,
            records: []
          });
        }

        // Add new records
        minuteDoc.records.push(...minuteMessages);
        minuteDoc.recordCount = minuteDoc.records.length;
        
        await minuteDoc.save();
      }
    } catch (error) {
      console.error('Error saving to database:', error);
    }
  }

  start() {
    this.server.listen(PORT, () => {
      console.log(`Listener service running on port ${PORT}`);
    });
  }
}

// Start the listener service
const listener = new ListenerService();
listener.start();

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down listener service...');
  const mongoose = require('mongoose');
  await mongoose.connection.close();
  process.exit(0);
});