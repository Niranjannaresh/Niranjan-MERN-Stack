const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const connectDB = require('../listener/db');
const TimeSeriesData = require('../listener/models/TimeSeriesData');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.SERVER_PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
connectDB();

// API Routes
app.get('/api/data', async (req, res) => {
  try {
    const { from, to, limit = 100 } = req.query;
    
    let query = {};
    
    if (from || to) {
      query.minute = {};
      if (from) query.minute.$gte = new Date(from);
      if (to) query.minute.$lte = new Date(to);
    }

    const data = await TimeSeriesData.find(query)
      .sort({ minute: -1 })
      .limit(parseInt(limit));

    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/data/latest', async (req, res) => {
  try {
    const latest = await TimeSeriesData.findOne()
      .sort({ minute: -1 })
      .limit(1);

    res.json(latest || { records: [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Socket.IO for real-time frontend updates
io.on('connection', (socket) => {
  console.log('Frontend client connected:', socket.id);

  // Send latest data on connection
  TimeSeriesData.findOne()
    .sort({ minute: -1 })
    .limit(1)
    .then(latest => {
      if (latest) {
        socket.emit('initial-data', latest);
      }
    });

  socket.on('disconnect', () => {
    console.log('Frontend client disconnected:', socket.id);
  });
});

// Watch for new data in MongoDB and emit to frontend
const changeStream = TimeSeriesData.watch();
changeStream.on('change', async (change) => {
  if (change.operationType === 'insert' || change.operationType === 'update') {
    const updatedDoc = await TimeSeriesData.findById(change.documentKey._id);
    io.emit('data-update', updatedDoc);
  }
});

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});