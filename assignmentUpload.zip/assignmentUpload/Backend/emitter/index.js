// const crypto = require('crypto');
// const { io } = require('socket.io-client');
// const data = require('../data.json');

// const ENCRYPTION_KEY = 'mysecretkey123456789012345678901234'; // 32 bytes for aes-256
// const ALGORITHM = 'aes-256-ctr';
// const LISTENER_URL = 'http://localhost:3001';

// class EmitterService {
//   constructor() {
//     this.socket = io(LISTENER_URL);
//     this.setupSocketHandlers();
//     this.startEmitting();
//   }

//   setupSocketHandlers() {
//     this.socket.on('connect', () => {
//       console.log('Connected to listener service');
//     });

//     this.socket.on('disconnect', () => {
//       console.log('Disconnected from listener service');
//     });

//     this.socket.on('connect_error', (error) => {
//       console.error('Connection error:', error.message);
//     });
//   }

//   generateRandomMessage() {
//     const name = data.names[Math.floor(Math.random() * data.names.length)];
//     const origin = data.origins[Math.floor(Math.random() * data.origins.length)];
//     const destination = data.destinations[Math.floor(Math.random() * data.destinations.length)];

//     const originalMessage = { name, origin, destination };
    
//     // Create SHA-256 hash of the original message
//     const hash = crypto.createHash('sha256')
//       .update(JSON.stringify(originalMessage))
//       .digest('hex');

//     // Add secret_key to the message
//     const messageWithSecret = {
//       ...originalMessage,
//       secret_key: hash
//     };

//     return messageWithSecret;
//   }

//   encryptMessage(message) {
//     const iv = crypto.randomBytes(16);
//     const cipher = crypto.createCipheriv(ALGORITHM, Buffer.from(ENCRYPTION_KEY), iv);
    
//     const encrypted = Buffer.concat([
//       cipher.update(JSON.stringify(message), 'utf8'),
//       cipher.final()
//     ]);

//     // Prepend IV to the encrypted data (IV doesn't need to be secret)
//     return iv.toString('hex') + ':' + encrypted.toString('hex');
//   }

//   generateMessageStream() {
//     // Random number between 49 and 499
//     const messageCount = Math.floor(Math.random() * 451) + 49;
//     const encryptedMessages = [];

//     for (let i = 0; i < messageCount; i++) {
//       const message = this.generateRandomMessage();
//       const encrypted = this.encryptMessage(message);
//       encryptedMessages.push(encrypted);
//     }

//     return encryptedMessages.join('|');
//   }

//   startEmitting() {
//     // Emit every 10 seconds
//     setInterval(() => {
//       if (this.socket.connected) {
//         const stream = this.generateMessageStream();
//         console.log(`Emitting stream with ${stream.split('|').length} encrypted messages`);
//         this.socket.emit('data-stream', stream);
//       } else {
//         console.log('Not connected to listener, skipping emission');
//       }
//     }, 10000);
//   }
// }

// // Start the emitter service
// new EmitterService();







const crypto = require('crypto');
const { io } = require('socket.io-client');
const data = require('../data.json');

// Fix: Ensure key is exactly 32 bytes
const ENCRYPTION_KEY = crypto.createHash('sha256')
  .update('mysecretkey')
  .digest('hex')
  .substring(0, 32); // 32 bytes for aes-256

const ALGORITHM = 'aes-256-ctr';
const LISTENER_URL = 'http://localhost:3001';

class EmitterService {
  constructor() {
    this.socket = io(LISTENER_URL);
    this.setupSocketHandlers();
    this.startEmitting();
  }

  setupSocketHandlers() {
    this.socket.on('connect', () => {
      console.log('Connected to listener service');
    });

    this.socket.on('disconnect', () => {
      console.log('Disconnected from listener service');
    });

    this.socket.on('connect_error', (error) => {
      console.error('Connection error:', error.message);
    });
  }

  generateRandomMessage() {
    const name = data.names[Math.floor(Math.random() * data.names.length)];
    const origin = data.origins[Math.floor(Math.random() * data.origins.length)];
    const destination = data.destinations[Math.floor(Math.random() * data.destinations.length)];

    const originalMessage = { name, origin, destination };
    
    // Create SHA-256 hash of the original message
    const hash = crypto.createHash('sha256')
      .update(JSON.stringify(originalMessage))
      .digest('hex');

    // Add secret_key to the message
    const messageWithSecret = {
      ...originalMessage,
      secret_key: hash
    };

    return messageWithSecret;
  }

  encryptMessage(message) {
    try {
      const iv = crypto.randomBytes(16);
      
      // Fix: Ensure key is Buffer of correct length
      const key = Buffer.from(ENCRYPTION_KEY, 'utf8');
      
      const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
      
      const encrypted = Buffer.concat([
        cipher.update(JSON.stringify(message), 'utf8'),
        cipher.final()
      ]);

      // Prepend IV to the encrypted data
      return iv.toString('hex') + ':' + encrypted.toString('hex');
    } catch (error) {
      console.error('Encryption error:', error.message);
      throw error;
    }
  }

  generateMessageStream() {
    // Random number between 49 and 499
    const messageCount = Math.floor(Math.random() * 451) + 49;
    const encryptedMessages = [];

    for (let i = 0; i < messageCount; i++) {
      const message = this.generateRandomMessage();
      const encrypted = this.encryptMessage(message);
      encryptedMessages.push(encrypted);
    }

    return encryptedMessages.join('|');
  }

  startEmitting() {
    // Emit every 10 seconds
    setInterval(() => {
      if (this.socket.connected) {
        try {
          const stream = this.generateMessageStream();
          console.log(`Emitting stream with ${stream.split('|').length} encrypted messages`);
          this.socket.emit('data-stream', stream);
        } catch (error) {
          console.error('Error generating stream:', error.message);
        }
      } else {
        console.log('Not connected to listener, skipping emission');
      }
    }, 10000);
  }
}

// Start the emitter service
new EmitterService();