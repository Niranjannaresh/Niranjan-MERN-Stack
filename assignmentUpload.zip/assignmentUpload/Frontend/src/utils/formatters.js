export const formatTimestamp = (timestamp) => {
  const date = new Date(timestamp);
  return date.toLocaleString();
};

export const truncateHash = (hash, length = 10) => {
  if (hash.length <= length) return hash;
  return `${hash.substring(0, length)}...`;
};

export const groupByMinute = (records) => {
  return records.reduce((acc, record) => {
    const minute = new Date(record.timestamp);
    minute.setSeconds(0, 0);
    const minuteKey = minute.toISOString();
    
    if (!acc[minuteKey]) {
      acc[minuteKey] = [];
    }
    acc[minuteKey].push(record);
    return acc;
  }, {});
};

export const calculateStats = (records) => {
  const stats = {
    total: records.length,
    uniqueOrigins: new Set(records.map(r => r.origin)).size,
    uniqueDestinations: new Set(records.map(r => r.destination)).size,
    uniquePeople: new Set(records.map(r => r.name)).size,
  };

  // Most popular origin
  const originCounts = records.reduce((acc, r) => {
    acc[r.origin] = (acc[r.origin] || 0) + 1;
    return acc;
  }, {});

  stats.mostPopularOrigin = Object.entries(originCounts)
    .sort((a, b) => b[1] - a[1])[0];

  return stats;
};