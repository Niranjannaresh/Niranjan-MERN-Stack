import axios from 'axios';

const API_BASE_URL = 'http://localhost:3000/api';

export const fetchLatestData = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/data/latest`);
    return response.data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

export const fetchDataByTimeRange = async (from, to, limit = 100) => {
  try {
    const params = new URLSearchParams();
    if (from) params.append('from', from);
    if (to) params.append('to', to);
    params.append('limit', limit);

    const response = await axios.get(`${API_BASE_URL}/data?${params.toString()}`);
    return response.data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};