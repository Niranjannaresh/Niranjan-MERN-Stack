import React, { useState, useEffect } from 'react';
import {
  Container,
  AppBar,
  Toolbar,
  Typography,
  Box,
  Chip,
  IconButton,
  Badge,
} from '@mui/material';
import {
  Security as SecurityIcon,
  Refresh as RefreshIcon,
  Storage as StorageIcon,
} from '@mui/icons-material';
import Dashboard from './components/Dashboard';
import ConnectionStatus from './components/ConnectionStatus';
import { initSocket } from './services/socket';
import { fetchLatestData } from './services/api';

function App() {
  const [data, setData] = useState(null);
  const [connected, setConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(null);

  useEffect(() => {
    // Fetch initial data
    loadLatestData();

    // Initialize socket connection
    const socket = initSocket();

    socket.on('connect', () => {
      console.log('Connected to server');
      setConnected(true);
    });

    socket.on('disconnect', () => {
      console.log('Disconnected from server');
      setConnected(false);
    });

    socket.on('initial-data', (initialData) => {
      setData(initialData);
      setLastUpdate(new Date());
    });

    socket.on('data-update', (updatedData) => {
      setData(updatedData);
      setLastUpdate(new Date());
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const loadLatestData = async () => {
    try {
      const latestData = await fetchLatestData();
      setData(latestData);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const totalMessages = data?.records?.length || 0;

  return (
    <Box sx={{ minHeight: '100vh', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
      <AppBar position="static" color="transparent" elevation={0}>
        <Toolbar>
          <SecurityIcon sx={{ mr: 2, color: 'white' }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1, color: 'white' }}>
            Encrypted Data Stream Monitor
          </Typography>
          <Chip
            icon={<StorageIcon />}
            label={`${totalMessages} Messages`}
            sx={{ mr: 2, bgcolor: 'rgba(255,255,255,0.9)' }}
          />
          <ConnectionStatus connected={connected} lastUpdate={lastUpdate} />
          <IconButton color="inherit" onClick={loadLatestData} sx={{ ml: 2, color: 'white' }}>
            <RefreshIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      <Container maxWidth="xl" sx={{ mt: 4, pb: 4 }}>
        <Dashboard data={data} />
      </Container>
    </Box>
  );
}

export default App;