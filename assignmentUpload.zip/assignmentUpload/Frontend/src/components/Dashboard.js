import React from 'react';
import {
  Grid,
  Paper,
  Typography,
  Box,
  Divider,
  Alert,
} from '@mui/material';
import {
  Timeline as TimelineIcon,
  ShowChart as ChartIcon,
  ListAlt as ListIcon,
} from '@mui/icons-material';
import DataStream from './DataStream';
import Statistics from './Statistics';
import MinuteGroup from './MinuteGroup';

function Dashboard({ data }) {
  if (!data || !data.records || data.records.length === 0) {
    return (
      <Alert severity="info" sx={{ mt: 4 }}>
        No data available. Waiting for emitter to send messages...
      </Alert>
    );
  }

  // Group records by minute for the timeline view
  const recordsByMinute = data.records.reduce((acc, record) => {
    const minute = new Date(record.timestamp);
    minute.setSeconds(0, 0);
    const minuteKey = minute.toISOString();
    
    if (!acc[minuteKey]) {
      acc[minuteKey] = [];
    }
    acc[minuteKey].push(record);
    return acc;
  }, {});

  return (
    <Grid container spacing={3}>
      {/* Statistics Section */}
      <Grid item xs={12}>
        <Paper elevation={3} sx={{ p: 3, borderRadius: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <ChartIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="h6">Statistics</Typography>
          </Box>
          <Divider sx={{ mb: 3 }} />
          <Statistics records={data.records} />
        </Paper>
      </Grid>

      {/* Timeline View */}
      <Grid item xs={12} md={6}>
        <Paper elevation={3} sx={{ p: 3, borderRadius: 3, height: '100%' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <TimelineIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="h6">Timeline (Grouped by Minute)</Typography>
          </Box>
          <Divider sx={{ mb: 3 }} />
          <Box sx={{ maxHeight: 500, overflow: 'auto' }}>
            {Object.entries(recordsByMinute).map(([minute, records]) => (
              <MinuteGroup key={minute} minute={minute} records={records} />
            ))}
          </Box>
        </Paper>
      </Grid>

      {/* Live Data Stream */}
      <Grid item xs={12} md={6}>
        <Paper elevation={3} sx={{ p: 3, borderRadius: 3, height: '100%' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <ListIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="h6">Live Data Stream</Typography>
          </Box>
          <Divider sx={{ mb: 3 }} />
          <DataStream records={data.records} />
        </Paper>
      </Grid>
    </Grid>
  );
}

export default Dashboard;