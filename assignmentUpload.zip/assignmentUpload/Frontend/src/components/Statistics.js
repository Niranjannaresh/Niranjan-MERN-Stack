import React, { useMemo } from 'react';
import {
  Grid,
  Paper,
  Typography,
  Box,
  LinearProgress,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Chip,
} from '@mui/material';
import {
  TrendingUp as TrendingUpIcon,
  People as PeopleIcon,
  LocationCity as LocationIcon,
  Timeline as TimelineIcon,
} from '@mui/icons-material';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line, Doughnut } from 'react-chartjs-2';
import { format, subHours } from 'date-fns';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

function Statistics({ records }) {
  const stats = useMemo(() => {
    const now = new Date();
    const oneHourAgo = subHours(now, 1);

    // Messages in last hour
    const lastHourMessages = records.filter(
      (r) => new Date(r.timestamp) > oneHourAgo
    ).length;

    // Unique origins and destinations
    const origins = new Set(records.map((r) => r.origin));
    const destinations = new Set(records.map((r) => r.destination));

    // Messages by minute (last 10 minutes)
    const messagesByMinute = [];
    for (let i = 9; i >= 0; i--) {
      const minute = subHours(now, i / 60);
      const count = records.filter(
        (r) => {
          const recordTime = new Date(r.timestamp);
          return recordTime >= minute && recordTime < subHours(minute, -1/60);
        }
      ).length;
      messagesByMinute.push(count);
    }

    // Top origins
    const originCounts = {};
    records.forEach((r) => {
      originCounts[r.origin] = (originCounts[r.origin] || 0) + 1;
    });

    const topOrigins = Object.entries(originCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    return {
      total: records.length,
      lastHour: lastHourMessages,
      uniqueOrigins: origins.size,
      uniqueDestinations: destinations.size,
      messagesByMinute,
      topOrigins,
    };
  }, [records]);

  const lineChartData = {
    labels: Array.from({ length: 10 }, (_, i) => `${i * 1}m ago`).reverse(),
    datasets: [
      {
        label: 'Messages per Minute',
        data: stats.messagesByMinute,
        borderColor: '#667eea',
        backgroundColor: 'rgba(102, 126, 234, 0.1)',
        tension: 0.4,
        fill: true,
      },
    ],
  };

  const lineChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
        },
      },
    },
  };

  const doughnutData = {
    labels: stats.topOrigins.map(([origin]) => origin),
    datasets: [
      {
        data: stats.topOrigins.map(([, count]) => count),
        backgroundColor: [
          '#667eea',
          '#764ba2',
          '#ff6b6b',
          '#4ecdc4',
          '#45b7d1',
        ],
        borderWidth: 0,
      },
    ],
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
      },
    },
  };

  return (
    <Grid container spacing={3}>
      {/* Summary Cards */}
      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ p: 2, textAlign: 'center' }}>
          <Avatar sx={{ bgcolor: 'primary.main', mx: 'auto', mb: 1 }}>
            <TrendingUpIcon />
          </Avatar>
          <Typography variant="h4">{stats.total}</Typography>
          <Typography variant="body2" color="textSecondary">
            Total Messages
          </Typography>
        </Paper>
      </Grid>

      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ p: 2, textAlign: 'center' }}>
          <Avatar sx={{ bgcolor: 'secondary.main', mx: 'auto', mb: 1 }}>
            <TimelineIcon />
          </Avatar>
          <Typography variant="h4">{stats.lastHour}</Typography>
          <Typography variant="body2" color="textSecondary">
            Last Hour
          </Typography>
        </Paper>
      </Grid>

      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ p: 2, textAlign: 'center' }}>
          <Avatar sx={{ bgcolor: 'success.main', mx: 'auto', mb: 1 }}>
            <LocationIcon />
          </Avatar>
          <Typography variant="h4">{stats.uniqueOrigins}</Typography>
          <Typography variant="body2" color="textSecondary">
            Unique Origins
          </Typography>
        </Paper>
      </Grid>

      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ p: 2, textAlign: 'center' }}>
          <Avatar sx={{ bgcolor: 'error.main', mx: 'auto', mb: 1 }}>
            <LocationIcon />
          </Avatar>
          <Typography variant="h4">{stats.uniqueDestinations}</Typography>
          <Typography variant="body2" color="textSecondary">
            Unique Destinations
          </Typography>
        </Paper>
      </Grid>

      {/* Charts */}
      <Grid item xs={12} md={8}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>
            Message Frequency (Last 10 Minutes)
          </Typography>
          <Box sx={{ height: 200 }}>
            <Line data={lineChartData} options={lineChartOptions} />
          </Box>
        </Paper>
      </Grid>

      <Grid item xs={12} md={4}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>
            Top Origins
          </Typography>
          <Box sx={{ height: 200 }}>
            <Doughnut data={doughnutData} options={doughnutOptions} />
          </Box>
        </Paper>
      </Grid>

      {/* Top Origins List */}
      <Grid item xs={12}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6" gutterBottom>
            Popular Routes
          </Typography>
          <List>
            {stats.topOrigins.map(([origin, count], index) => (
              <ListItem key={origin}>
                <ListItemAvatar>
                  <Avatar sx={{ bgcolor: `hsl(${index * 72}, 70%, 50%)` }}>
                    {index + 1}
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={origin}
                  secondary={`${count} messages`}
                />
                <Chip
                  label={`${Math.round((count / stats.total) * 100)}%`}
                  color="primary"
                  size="small"
                />
              </ListItem>
            ))}
          </List>
        </Paper>
      </Grid>
    </Grid>
  );
}

export default Statistics;