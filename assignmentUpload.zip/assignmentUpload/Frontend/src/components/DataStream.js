import React from 'react';
import {
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Typography,
  Box,
  Chip,
  Paper,
  Fade,
} from '@mui/material';
import {
  Person as PersonIcon,
  LocationOn as LocationIcon,
  VpnKey as KeyIcon,
  AccessTime as TimeIcon,
} from '@mui/icons-material';
import { formatDistanceToNow } from 'date-fns';
import MessageCard from './MessageCard';

function DataStream({ records }) {
  // Show last 20 messages in reverse chronological order
  const recentRecords = [...records]
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 20);

  if (recentRecords.length === 0) {
    return (
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <Typography color="textSecondary">
          No messages in stream
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ maxHeight: 500, overflow: 'auto', pr: 1 }}>
      <List>
        {recentRecords.map((record, index) => (
          <Fade in={true} timeout={500} key={`${record.timestamp}-${index}`}>
            <ListItem
              alignItems="flex-start"
              sx={{
                mb: 2,
                bgcolor: 'background.paper',
                borderRadius: 2,
                border: '1px solid',
                borderColor: 'divider',
                '&:hover': {
                  bgcolor: 'action.hover',
                  transform: 'translateX(5px)',
                  transition: 'all 0.3s',
                },
              }}
            >
              <ListItemAvatar>
                <Avatar sx={{ bgcolor: 'primary.main' }}>
                  <PersonIcon />
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                      {record.name}
                    </Typography>
                    <Chip
                      size="small"
                      icon={<TimeIcon />}
                      label={formatDistanceToNow(new Date(record.timestamp), { addSuffix: true })}
                      variant="outlined"
                    />
                  </Box>
                }
                secondary={
                  <Box sx={{ mt: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <LocationIcon fontSize="small" sx={{ mr: 0.5, color: 'success.main' }} />
                        <Typography variant="body2" color="text.secondary">
                          From: {record.origin}
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <LocationIcon fontSize="small" sx={{ mr: 0.5, color: 'error.main' }} />
                        <Typography variant="body2" color="text.secondary">
                          To: {record.destination}
                        </Typography>
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <KeyIcon fontSize="small" sx={{ color: 'warning.main' }} />
                      <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'monospace' }}>
                        {record.secret_key.substring(0, 20)}...
                      </Typography>
                    </Box>
                  </Box>
                }
              />
            </ListItem>
          </Fade>
        ))}
      </List>
    </Box>
  );
}

export default DataStream;