import React, { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  IconButton,
  Collapse,
  Divider,
  Tooltip,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  LocationOn as LocationIcon,
  VerifiedUser as VerifiedIcon,
  AccessTime as TimeIcon,
  Fingerprint as FingerprintIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';

function MessageCard({ message }) {
  const [expanded, setExpanded] = useState(false);

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  return (
    <Card sx={{ mb: 2, borderLeft: '4px solid', borderLeftColor: 'primary.main' }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <VerifiedIcon color="primary" fontSize="small" />
            <Typography variant="h6" component="div">
              {message.name}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Chip
              size="small"
              icon={<TimeIcon />}
              label={format(new Date(message.timestamp), 'HH:mm:ss')}
              variant="outlined"
            />
            <Tooltip title={expanded ? "Show less" : "Show more"}>
              <IconButton
                onClick={handleExpandClick}
                size="small"
                sx={{
                  transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)',
                  transition: 'transform 0.3s',
                }}
              >
                <ExpandMoreIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        <Box sx={{ display: 'flex', gap: 3, mb: 2 }}>
          <Box>
            <Typography variant="caption" color="textSecondary" display="block">
              Origin
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <LocationIcon fontSize="small" color="success" />
              <Typography variant="body2">{message.origin}</Typography>
            </Box>
          </Box>
          <Box>
            <Typography variant="caption" color="textSecondary" display="block">
              Destination
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <LocationIcon fontSize="small" color="error" />
              <Typography variant="body2">{message.destination}</Typography>
            </Box>
          </Box>
        </Box>

        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <Divider sx={{ my: 2 }} />
          <Box>
            <Typography variant="caption" color="textSecondary" display="block" gutterBottom>
              Secret Key (SHA-256)
            </Typography>
            <Box
              sx={{
                bgcolor: 'grey.100',
                p: 2,
                borderRadius: 1,
                fontFamily: 'monospace',
                fontSize: '0.75rem',
                wordBreak: 'break-all',
                display: 'flex',
                alignItems: 'center',
                gap: 1,
              }}
            >
              <FingerprintIcon fontSize="small" color="action" />
              {message.secret_key}
            </Box>
          </Box>
        </Collapse>
      </CardContent>
    </Card>
  );
}

export default MessageCard;