import React, { useState } from 'react';
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Box,
  Chip,
  Avatar,
  Stack,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  AccessTime as TimeIcon,
  Message as MessageIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';
import MessageCard from './MessageCard';

function MinuteGroup({ minute, records }) {
  const [expanded, setExpanded] = useState(false);

  const minuteTime = new Date(minute);
  const messageCount = records.length;

  // Get unique names for preview
  const uniqueNames = [...new Set(records.map((r) => r.name))].slice(0, 3);

  return (
    <Accordion
      expanded={expanded}
      onChange={() => setExpanded(!expanded)}
      sx={{ mb: 1 }}
    >
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
          <Avatar sx={{ bgcolor: 'primary.main', width: 32, height: 32 }}>
            <TimeIcon fontSize="small" />
          </Avatar>
          <Box sx={{ flex: 1 }}>
            <Typography variant="subtitle1">
              {format(minuteTime, 'HH:mm')}
            </Typography>
            <Typography variant="caption" color="textSecondary">
              {format(minuteTime, 'MMMM d, yyyy')}
            </Typography>
          </Box>
          <Chip
            icon={<MessageIcon />}
            label={`${messageCount} messages`}
            color="primary"
            variant="outlined"
            size="small"
          />
        </Box>
      </AccordionSummary>
      <AccordionDetails>
        <Box sx={{ mb: 2 }}>
          <Typography variant="body2" color="textSecondary" gutterBottom>
            People: {uniqueNames.join(', ')}
            {records.length > 3 && '...'}
          </Typography>
        </Box>
        <Stack spacing={2}>
          {records.map((record, index) => (
            <MessageCard key={`${record.timestamp}-${index}`} message={record} />
          ))}
        </Stack>
      </AccordionDetails>
    </Accordion>
  );
}

export default MinuteGroup;