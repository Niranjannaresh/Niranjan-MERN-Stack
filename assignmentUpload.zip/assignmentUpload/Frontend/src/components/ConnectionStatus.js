import React from 'react';
import {
  Chip,
  Tooltip,
  Box,
} from '@mui/material';
import {
  Wifi as WifiIcon,
  WifiOff as WifiOffIcon,
  Update as UpdateIcon,
} from '@mui/icons-material';
import { formatDistanceToNow } from 'date-fns';

function ConnectionStatus({ connected, lastUpdate }) {
  return (
    <Box sx={{ display: 'flex', gap: 1 }}>
      <Tooltip title={connected ? 'Connected to server' : 'Disconnected from server'}>
        <Chip
          icon={connected ? <WifiIcon /> : <WifiOffIcon />}
          label={connected ? 'Connected' : 'Disconnected'}
          color={connected ? 'success' : 'error'}
          size="small"
          variant="outlined"
          sx={{ color: 'white', borderColor: 'white' }}
        />
      </Tooltip>
      
      {lastUpdate && (
        <Tooltip title={`Last update: ${lastUpdate.toLocaleString()}`}>
          <Chip
            icon={<UpdateIcon />}
            label={formatDistanceToNow(lastUpdate, { addSuffix: true })}
            size="small"
            variant="outlined"
            sx={{ color: 'white', borderColor: 'white' }}
          />
        </Tooltip>
      )}
    </Box>
  );
}

export default ConnectionStatus;